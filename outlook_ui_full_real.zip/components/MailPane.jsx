'use client'
import { useEffect, useRef } from 'react'
import styles from './MailPane.module.css'
import { useMail } from './MailContext'

export default function MailPane({ mailId, onClose }){
  const { openById } = useMail()
  const mail = openById(mailId)
  const containerRef = useRef(null)
  useEffect(()=>{ if(mail && containerRef.current){ containerRef.current.scrollTo(0,0); containerRef.current.classList.add(styles.animateIn); const t=setTimeout(()=>containerRef.current?.classList.remove(styles.animateIn),300); return ()=>clearTimeout(t)} },[mail])
  if(!mail) return (<aside className={styles.pane}><div className={styles.empty}><h3>Select a message</h3><p className={styles.hint}>Choose a message to view details.</p></div></aside>)
  return (
    <aside className={styles.pane}>
      <div className={styles.container} ref={containerRef}>
        <header className={styles.header}>
          <div><h2 className={styles.subject}>{mail.subject}</h2><div className={styles.meta}><strong>{mail.from}</strong> · {mail.time}</div></div>
          <div className={styles.actions}><button className={styles.closeBtn} onClick={onClose}>Close</button><button className={styles.primaryBtn}>Reply</button></div>
        </header>
        <article className={styles.body}>
          <div className={styles.htmlBody} dangerouslySetInnerHTML={{__html: mail.html}} />
          {mail.attachments?.length>0 && (<section className={styles.attachments}><h4>Attachments</h4><div className={styles.attachmentList}>{mail.attachments.map((a,i)=>(<div key={i} className={styles.attachment}>📎 {a}</div>))}</div></section>)}
        </article>
      </div>
    </aside>
  )
}
