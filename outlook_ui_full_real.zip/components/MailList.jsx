'use client'
import styles from './MailList.module.css'
import { useMail } from './MailContext'
export default function MailList({ folder, onOpen }){
  const { mails } = useMail()
  const list = mails.filter(m=>m.folder===folder)
  return (
    <section className={styles.list} aria-label="mail list">
      <div className={styles.header}><div className={styles.row}><h3>{folder.charAt(0).toUpperCase()+folder.slice(1)}</h3></div></div>
      <div className={styles.items}>
        {list.map(m=>(
          <article key={m.id} className={styles.card} onClick={()=>onOpen(m.id)} role="button" tabIndex={0}>
            <div className={styles.avatar}>{m.from[0]}</div>
            <div className={styles.content}>
              <div className={styles.top}><div className={styles.from}>{m.from}</div><div className={styles.time}>{m.time}</div></div>
              <div className={styles.subject}>{m.subject}</div>
              <div className={styles.snippet}>{m.snippet}</div>
            </div>
          </article>
        ))}
        {list.length===0 && <div className={styles.empty}>No messages</div>}
      </div>
    </section>
  )
}
