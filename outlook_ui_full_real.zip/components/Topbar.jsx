'use client'
import Link from 'next/link'
import styles from './Topbar.module.css'
import IconSearch from './icons/IconSearch'
export default function Topbar(){
  return (
    <header className={styles.top}>
      <div className={styles.left}>
        <div className={styles.logo}>F</div>
        <Link href="/" className={styles.title}>Frontline Mail</Link>
      </div>
      <div className={styles.center}>
        <div className={styles.searchWrap}><IconSearch/><input className={styles.search} placeholder="Search mail and people..." /></div>
      </div>
      <div className={styles.right}>
        <Link href="/compose"><button className={styles.compose}>Compose</button></Link>
        <Link href="/settings"><div className={styles.avatar}>KS</div></Link>
      </div>
    </header>
  )
}
