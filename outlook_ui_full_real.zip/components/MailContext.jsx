'use client'
import { createContext, useContext, useState } from 'react'
import { mails as seed } from '../app/data/mails'

const MailContext = createContext(null)

export function MailProvider({ children }){
  const [mails, setMails] = useState(seed)
  function openById(id){ return mails.find(m=>m.id===id) }
  function sendMail(mail){ setMails(prev=>[mail,...prev]) }
  return <MailContext.Provider value={{mails, setMails, openById, sendMail}}>{children}</MailContext.Provider>
}

export function useMail(){ return useContext(MailContext) }
