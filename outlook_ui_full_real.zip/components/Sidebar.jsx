'use client'
import Link from 'next/link'
import styles from './Sidebar.module.css'
import { folders } from '../app/data/mails'

export default function Sidebar({ current }){
  return (
    <aside className={styles.side}>
      <div className={styles.tools}>
        <Link href="/compose"><button className={styles.compose}>Compose</button></Link>
        <div className={styles.quick}>Today</div>
      </div>
      <nav className={styles.nav}>
        {folders.map(f=>(
          <Link key={f} href={`/mailbox/${f}`} className={styles.item + (current===f ? ' '+styles.active : '')}>
            <span className={styles.label}>{f.charAt(0).toUpperCase()+f.slice(1)}</span>
          </Link>
        ))}
      </nav>
      <div className={styles.footer}>frontline@kunal.tech</div>
    </aside>
  )
}
