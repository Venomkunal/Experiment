# Frontline Mail - Full Real (Mobile Responsive)

This is a full Next.js App Router starter that includes:
- App Router (`app/`) layout and pages
- Mailboxes (routes: /mailbox/[folder])
- Compose page (/compose)
- Message direct view (/message/[id])
- Settings page (/settings)
- MailProvider context with mock data in app/data/mails.js
- Interactive list and reading pane
- Mobile-responsive styles and CSS Modules

Run locally:
1. unzip the archive
2. cd into the folder
3. npm install
4. npm run dev

Notes:
- This is a front-end demo with mock data. For persistence, integrate API routes or a backend/db.
