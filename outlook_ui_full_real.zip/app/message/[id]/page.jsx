'use client'
import Topbar from '../../../components/Topbar'
import Sidebar from '../../../components/Sidebar'
import MailPane from '../../../components/MailPane'
import { MailProvider } from '../../../components/MailContext'

export default function MessagePage({ params }){
  const id = params.id
  return (
    <MailProvider>
      <div style={{minHeight:'100vh'}}>
        <Topbar />
        <div className='container' style={{display:'flex',gap:16}}>
          <Sidebar current='' />
          <div style={{flex:1,display:'flex'}}>
            <MailPane mailId={id} onClose={()=>{}} />
          </div>
        </div>
      </div>
    </MailProvider>
  )
}
