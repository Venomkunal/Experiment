import './globals.css'
export const metadata = { title: 'Frontline Mail - Full Real' }
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
