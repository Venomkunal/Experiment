'use client'
import { useState } from 'react'
import Topbar from '../../components/Topbar'
import Sidebar from '../../components/Sidebar'
import { MailProvider, useMail } from '../../components/MailContext'
import styles from './page.module.css'
import { useRouter } from 'next/navigation'

function ComposeForm(){
  const { sendMail } = useMail()
  const [to,setTo] = useState('')
  const [subject,setSubject] = useState('')
  const [body,setBody] = useState('')
  const router = useRouter()
  function submit(e){
    e.preventDefault()
    const newMail = { id: 'sent-'+Date.now(), folder:'sent', from: to||'me@you', subject: subject||'(no subject)', snippet: body.slice(0,80), time: 'Now', html: `<p>${body.replace(/\n/g,'<br/>')}</p>` }
    sendMail(newMail)
    router.push('/mailbox/sent')
  }
  return (
    <form className={styles.form} onSubmit={submit}>
      <label>To<input value={to} onChange={e=>setTo(e.target.value)} placeholder='recipient@example.com'/></label>
      <label>Subject<input value={subject} onChange={e=>setSubject(e.target.value)} placeholder='Subject'/></label>
      <label>Body<textarea rows={8} value={body} onChange={e=>setBody(e.target.value)} placeholder='Write your message...'/></label>
      <div className={styles.actions}><button type="submit" className={styles.send}>Send</button></div>
    </form>
  )
}

export default function ComposePage(){
  return (
    <MailProvider>
      <div style={{minHeight:'100vh'}}>
        <Topbar />
        <div className='container' style={{display:'flex',gap:16}}>
          <Sidebar current='compose' />
          <div style={{flex:1}}>
            <h2>Compose</h2>
            <ComposeForm />
          </div>
        </div>
      </div>
    </MailProvider>
  )
}
