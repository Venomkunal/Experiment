export const folders = ['inbox','starred','sent','drafts','archive','spam','trash']

function make(id, folder, i){
  return {
    id: `${folder}-${id}`,
    folder,
    from: ['Microsoft','Cloud Team','Rinalyn','Postmaster'][i%4],
    subject: `${folder.toUpperCase()}: Welcome message ${id}`,
    snippet: 'This is a sample preview of the message body. Click to open.',
    time: ['8:27 AM','Wed','Thu','Mon'][i%4],
    html: `<p>Hello — this is message <strong>${id}</strong> in <em>${folder}</em>.</p><p>Mock content for testing the UI.</p>`,
    attachments: i%3===0 ? ['invoice.pdf','image.png'] : []
  }
}

export const mails = folders.flatMap((f,fi)=>{
  return Array.from({length:6}).map((_,i)=>make(i+1,f,fi+i))
})
