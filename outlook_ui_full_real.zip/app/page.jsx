import Link from 'next/link'
import Topbar from '../components/Topbar'
import styles from './page.module.css'
import { MailProvider } from '../components/MailContext'

export default function Home(){
  return (
    <MailProvider>
      <div className={styles.shell}>
        <Topbar />
        <main className='container'>
          <h1>Welcome to Frontline Mail</h1>
          <p>Choose a mailbox from the sidebar or go to <Link href='/mailbox/inbox'>Inbox</Link>.</p>
        </main>
      </div>
    </MailProvider>
  )
}
