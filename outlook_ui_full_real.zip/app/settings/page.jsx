import Topbar from '../../components/Topbar'
import Sidebar from '../../components/Sidebar'
export default function Settings(){
  return (
    <div style={{minHeight:'100vh'}}>
      <Topbar />
      <div className='container' style={{display:'flex',gap:16}}>
        <Sidebar current='settings' />
        <div style={{flex:1}}>
          <h2>Settings</h2>
          <p>Account: frontline@kunal.tech</p>
          <p>Theme: Default</p>
        </div>
      </div>
    </div>
  )
}
