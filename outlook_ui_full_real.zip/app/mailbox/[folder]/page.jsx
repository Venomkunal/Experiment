'use client'
import { useState } from 'react'
import Topbar from '../../../components/Topbar'
import Sidebar from '../../../components/Sidebar'
import MailList from '../../../components/MailList'
import MailPane from '../../../components/MailPane'
import { MailProvider } from '../../../components/MailContext'
import styles from './page.module.css'

export default function MailboxPage({ params }){
  const folder = params.folder || 'inbox'
  const [openId, setOpenId] = useState(null)
  return (
    <MailProvider>
      <div className={styles.shell}>
        <Topbar />
        <div className='container' style={{display:'flex',gap:16}}>
          <Sidebar current={folder} />
          <div className={styles.workspace}>
            <MailList folder={folder} onOpen={setOpenId} />
            <MailPane mailId={openId} onClose={()=>setOpenId(null)} />
          </div>
        </div>
      </div>
    </MailProvider>
  )
}
